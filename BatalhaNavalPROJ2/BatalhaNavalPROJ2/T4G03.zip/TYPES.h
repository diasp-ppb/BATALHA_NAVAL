#ifndef _TYPES
#define _TYPES

template <typename T>
struct Position
{
	T lin, col;
};

#endif 